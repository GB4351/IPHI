﻿using System;

namespace IPHISDAL
{
    public class RegistrationData
    {
    }
}
