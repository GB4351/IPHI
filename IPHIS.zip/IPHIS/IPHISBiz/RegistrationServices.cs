﻿using System;

namespace IPHISBiz
{
    public class RegistrationServices
    {
    }
}
