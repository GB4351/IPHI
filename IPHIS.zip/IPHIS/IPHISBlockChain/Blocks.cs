﻿using System;

namespace IPHISBlockChain
{
    public class Blocks
    {
    }
}
